const catalog={
 nails:{image:'assets/manicure-pink.webp',alt:'Маникюр с нежным дизайном из галереи Яратам',source:'2gis',items:[['Классический маникюр','Без покрытия','1 000 ₽'],['Маникюр с гель-лаком','Снятие нашего покрытия · ведущий мастер','2 400 ₽'],['Полный педикюр с покрытием','Ведущий мастер','3 000 ₽'],['Японский маникюр','Уход без цветного покрытия · ведущий мастер','2 100 ₽']]},
 brows:{image:'assets/eyes.webp',alt:'Брови и ресницы из галереи салона Яратам',source:'2gis',items:[['Коррекция бровей','Оформление формы','800 ₽'],['Окрашивание бровей','Подбор оттенка','800 ₽'],['Комплекс для бровей','Укладка, коррекция и окрашивание','1 800 ₽'],['Ламинирование ресниц','Топ-мастер','1 800 ₽']]},
 spa:{image:'assets/salon.webp',alt:'Светлый интерьер салона Яратам',source:'2gis',items:[['SPA-уход для рук','Подробности процедуры уточняйте у администратора','500 ₽'],['Массаж','Программу и длительность подберёт администратор','По запросу'],['SPA-программы','Уточните состав и доступное время','По запросу']]},
 makeup:{image:'assets/makeup.webp',alt:'Результат макияжа из галереи салона Яратам',source:'yandex',items:[['Полный образ','Макияж и локоны','6 000 ₽'],['Экспресс-образ за час','Нюдовый макияж и лёгкие локоны','3 800 ₽']]}
};
const tabs=[...document.querySelectorAll('[role="tab"]')];
function setCategory(key){
 const data=catalog[key];
 const list=document.querySelector('#service-list');
 list.replaceChildren();
 data.items.forEach(([name,note,price])=>{
  const row=document.createElement('div');row.className='service-row';
  const copy=document.createElement('div');
  const title=document.createElement('h3');title.textContent=name;
  const detail=document.createElement('p');detail.textContent=note;
  copy.append(title,detail);
  const amount=document.createElement('span');amount.className='service-price';amount.textContent=price;
  row.append(copy,amount);list.append(row);
 });
 const image=document.querySelector('#service-image');image.src=data.image;image.alt=data.alt;
 tabs.forEach(tab=>{const active=tab.dataset.category===key;tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1;});
 document.querySelector('#service-panel').setAttribute('aria-labelledby',`tab-${key}`);
 const source=document.querySelector('#service-source');
 source.textContent=data.source==='2gis'?'Цены из прайса 2ГИС от 25.06.2026. Итоговая стоимость зависит от мастера и состава услуги — уточняйте при записи.':'Цены из карточки Яндекс Карт. Наличие услуги и актуальную стоимость уточняйте у администратора.';
 const link=document.querySelector('#full-price-link');
 link.href=data.source==='2gis'?'https://2gis.ru/kazan/firm/70000001057889930/tab/prices':'https://yandex.ru/maps/org/yaratam/98374468371/prices/';
}
tabs.forEach((tab,index)=>{
 tab.addEventListener('click',()=>setCategory(tab.dataset.category));
 tab.addEventListener('keydown',event=>{
  let next;
  if(event.key==='ArrowRight')next=(index+1)%tabs.length;
  if(event.key==='ArrowLeft')next=(index-1+tabs.length)%tabs.length;
  if(event.key==='Home')next=0;
  if(event.key==='End')next=tabs.length-1;
  if(next!==undefined){event.preventDefault();setCategory(tabs[next].dataset.category);tabs[next].focus();}
 });
});
setCategory('nails');
const menuButton=document.querySelector('.menu-toggle');
const menu=document.querySelector('#mobile-nav');
function closeMenu(){menu.hidden=true;menuButton.setAttribute('aria-expanded','false');menuButton.setAttribute('aria-label','Открыть меню');}
menuButton.addEventListener('click',()=>{const isOpen=menuButton.getAttribute('aria-expanded')==='true';menu.hidden=isOpen;menuButton.setAttribute('aria-expanded',String(!isOpen));menuButton.setAttribute('aria-label',isOpen?'Открыть меню':'Закрыть меню');});
menu.querySelectorAll('a').forEach(link=>link.addEventListener('click',closeMenu));
const photos=[...document.querySelectorAll('.gallery-item')];
const dialog=document.querySelector('.lightbox');
let photoIndex=0;
function showPhoto(index){photoIndex=(index+photos.length)%photos.length;const photo=photos[photoIndex];document.querySelector('#lightbox-image').src=photo.dataset.full;document.querySelector('#lightbox-image').alt=photo.querySelector('img').alt;document.querySelector('#lightbox-caption').textContent=photo.dataset.caption;document.querySelector('#photo-counter').textContent=`${photoIndex+1} / ${photos.length}`;}
photos.forEach((photo,index)=>photo.addEventListener('click',()=>{showPhoto(index);dialog.showModal();document.body.classList.add('modal-open');}));
document.querySelector('.lightbox-close').addEventListener('click',()=>dialog.close());
document.querySelector('#photo-prev').addEventListener('click',()=>showPhoto(photoIndex-1));
document.querySelector('#photo-next').addEventListener('click',()=>showPhoto(photoIndex+1));
dialog.addEventListener('close',()=>document.body.classList.remove('modal-open'));
dialog.addEventListener('click',event=>{if(event.target!==dialog)return;const rect=dialog.getBoundingClientRect();if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)dialog.close();});
document.addEventListener('keydown',event=>{if(event.key==='Escape')closeMenu();if(dialog.open){if(event.key==='ArrowLeft')showPhoto(photoIndex-1);if(event.key==='ArrowRight')showPhoto(photoIndex+1);}});
